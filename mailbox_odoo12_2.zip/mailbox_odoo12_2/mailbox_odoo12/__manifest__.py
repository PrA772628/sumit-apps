
{
    'name': 'Mailbox (Odoo_12 Inbox)',
    'category': 'Website',
    'author': 'VperfectCS',
    'website': 'http://www.vperfectcs.com/',
    'version': '12.0.0.1',
    'description':
        """
Mailbox (Odoo Inbox)
========================
        """,
    'depends': ['website', 'mail', 'contacts','project','base','fetchmail_thread_default'],
    'data': [
        'data/data.xml',
        'security/ir.model.access.csv',
        'views/template.xml',
        # 'views/mail_message.xml'
    ],
    'installable': True,
    'bootstrap': True,  # load translations for login screen
    'application': True,
}
