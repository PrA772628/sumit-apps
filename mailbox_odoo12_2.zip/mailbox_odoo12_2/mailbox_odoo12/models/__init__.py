# -*- coding: utf-8 -*-

from . import mail_message
from . import odoo_inbox
