# -*- coding: utf-8 -*-

import base64
import logging
import psycopg2
import smtplib
import re
from odoo import _, api, fields, models
from datetime import datetime, timedelta
from odoo import tools
from odoo.tools.safe_eval import safe_eval
from odoo.addons.base.models.ir_mail_server import MailDeliveryException
from email.mime.multipart import MIMEMultipart

from email.mime.text import MIMEText

from email.mime.base import MIMEBase

from email import encoders

_logger = logging.getLogger(__name__)


class MessageTag(models.Model):
    _name = "message.tag"
    _description = "Message Tag"

    name = fields.Char(string='Tag Name')
    user_id = fields.Many2one('res.users', 'Owner', default=lambda self: self.env.user)
    partner_id = fields.Many2one('res.partner', string='Responsible', related='user_id.partner_id', readonly=True)


class MessageFolder(models.Model):
    _name = "message.folder"
    _description = "Message Folder"

    name = fields.Char(string='Folder Name')
    user_id = fields.Many2one('res.users', 'Owner', default=lambda self: self.env.user)
    partner_id = fields.Many2one('res.partner', string='Responsible', related='user_id.partner_id', readonly=True)


class Message(models.Model):
    _inherit = 'mail.message'

    msg_unread = fields.Boolean('Message Read')
    message_label = fields.Selection([('inbox', 'Inbox'), ('starred', 'Starred'), ('done', 'Done'), ('snoozed', 'Snoozed'), ('draft', 'Draft'), ('sent', 'SENT'), ('trash', 'TRASH')], string='Message Label', default="inbox")
    draft_message_id = fields.Char(string='Draft Message ID')
    snoozed_time = fields.Datetime('Snoozed Time')
    partner_followers = fields.Many2many('res.partner', 'mail_message_partner_rel', 'mail_id', 'partner_id', string='Partners')
    tag_ids = fields.Many2many('message.tag', 'mail_message_tags_rel', 'mail_id', 'tag_id', string='Tag')
    folder_id = fields.Many2one('message.folder', string='Folder')
    email_cc_ids = fields.Many2many('res.partner', 'mail_notification_cc', 'message_id', 'partner_id', string='CC',
        help='Partners that have a notification pushing this message in their mailboxes',store=True)
    email_bcc_ids = fields.Many2many('res.partner', 'mail_notification_bcc', 'message_id', 'partner_id', string='BCC',
        help='Partners that have a notification pushing this message in their mailboxes')
    email_to=fields.Char("email_to")
    email_bcc=fields.Char("email_bcc")
    email_cc=fields.Char("email_cc")
    task_id=fields.Many2one("project.task",string="assign task")
    @api.model
    def create(self, values):
        rec = super(Message, self).create(values)
        return rec

    def get_messages_time(self, your_time=None):
        if your_time == 'tomorrow':
            snooze = fields.Datetime.context_timestamp(self, datetime.now() + timedelta(days=1)).strftime("%a %I:%M %p")
        else:
            snooze = fields.Datetime.context_timestamp(self, datetime.now() + timedelta(hours=2)).strftime("%I:%M %p")
        return snooze

    @api.model
    def set_to_inbox(self):
        domain = [('message_label', '=', 'snoozed')]
        all_message = self.sudo().search(domain)
        for msg in all_message:
            now = fields.Datetime.from_string(fields.Datetime.now())
            snoozed_time = fields.Datetime.from_string(msg.snoozed_time)
            if snoozed_time and snoozed_time <= now:
                msg.message_label = 'inbox'

    @api.model
    def message_fetch(self, domain, limit=20):
        domain += [('message_type', '!=', 'email')]
        return self.search(domain, limit=limit).message_format()


class Partner(models.Model):
    _inherit = "res.partner"

    @api.model
    def get_needaction_count(self):
        """ compute the number of needaction of the current user """
        if self.env.user.partner_id:
            self.env.cr.execute("""
                SELECT count(*) as needaction_count
                FROM mail_message_res_partner_needaction_rel R
                LEFT JOIN mail_message msg ON (msg.id=R.mail_message_id)
                WHERE R.res_partner_id = %s AND (R.is_read = false OR R.is_read IS NULL) AND msg.message_type != 'email'""", (self.env.user.partner_id.id,))
            return self.env.cr.dictfetchall()[0].get('needaction_count')
        _logger.error('Call to needaction_count without partner_id')
        return 0

    @api.model
    def _notify_prepare_email_values(self, message):
        mail_values = super(Partner, self)._notify_prepare_email_values(message)
        cc_email_list = message.email_cc_ids.mapped('email')
        bcc_email_list = message.email_bcc_ids.mapped('email')
        cc_bcc = {
            'email_cc': ",".join(cc_email_list),
            'email_bcc': ",".join(bcc_email_list),
        }
        mail_values.update(cc_bcc)
        return mail_values


class MailMail(models.Model):
    _inherit = 'mail.mail'

    email_bcc = fields.Char(string='Bcc', help='Black Carbon copy message recipients')

    @api.multi
    def _send(self, auto_commit=False, raise_exception=False, smtp_session=None):
        
        IrMailServer = self.env['ir.mail_server']
        IrAttachment = self.env['ir.attachment']
        for mail_id in self.ids:
            success_pids = []
            failure_type = None
            processing_pid = None
            mail = None
            try:
                mail = self.browse(mail_id)
                if mail.state != 'outgoing':
                    if mail.state != 'exception' and mail.auto_delete:
                        mail.sudo().unlink()
                    continue

                # remove attachments if user send the link with the access_token
                body = mail.body_html or ''
                attachments = mail.attachment_ids
                for link in re.findall(r'/web/(?:content|image)/([0-9]+)', body):
                    attachments = attachments - IrAttachment.browse(int(link))

                # load attachment binary data with a separate read(), as prefetching all
                # `datas` (binary field) could bloat the browse cache, triggerring
                # soft/hard mem limits with temporary data.
                attachments = [(a['datas_fname'], base64.b64decode(a['datas']), a['mimetype'])
                               for a in attachments.sudo().read(['datas_fname', 'datas', 'mimetype']) if a['datas'] is not False]
                # specific behavior to customize the send email for notified partners
                email_list = []
                if mail.email_to:
                    email_list.append(mail._send_prepare_values())
                for partner in mail.recipient_ids:
                    values = mail._send_prepare_values(partner=partner)
                    values['partner_id'] = partner
                    email_list.append(values)

                # headers
                headers = {}
                ICP = self.env['ir.config_parameter'].sudo()
                bounce_alias = ICP.get_param("mail.bounce.alias")
                catchall_domain = ICP.get_param("mail.catchall.domain")
                if bounce_alias and catchall_domain:
                    if mail.model and mail.res_id:
                        headers['Return-Path'] = '%s+%d-%s-%d@%s' % (bounce_alias, mail.id, mail.model, mail.res_id, catchall_domain)
                    else:
                        headers['Return-Path'] = '%s+%d@%s' % (bounce_alias, mail.id, catchall_domain)
                if mail.headers:
                    try:
                        headers.update(safe_eval(mail.headers))
                    except Exception:
                        pass

                # Writing on the mail object may fail (e.g. lock on user) which
                # would trigger a rollback *after* actually sending the email.
                # To avoid sending twice the same email, provoke the failure earlier
                mail.write({
                    'state': 'exception',
                    'failure_reason': _('Error without exception. Probably due do sending an email without computed recipients.'),
                })
                # Update notification in a transient exception state to avoid concurrent
                # update in case an email bounces while sending all emails related to current
                # mail record.
                notifs = self.env['mail.notification'].search([
                    ('is_email', '=', True),
                    ('mail_id', 'in', mail.ids),
                    ('email_status', 'not in', ('sent', 'canceled'))
                ])
                if notifs:
                    notif_msg = _('Error without exception. Probably due do concurrent access update of notification records. Please see with an administrator.')
                    notifs.sudo().write({
                        'email_status': 'exception',
                        'failure_type': 'UNKNOWN',
                        'failure_reason': notif_msg,
                    })

                # build an RFC2822 email.message.Message object and send it without queuing
                res = None
               
                for email in email_list:
                    msg = IrMailServer.build_email(
                        email_from=mail.email_from,
                        email_to=email.get('email_to'),
                        subject=mail.subject,
                        body=email.get('body'),
                        body_alternative=email.get('body_alternative'),
                        email_cc=tools.email_split(mail.email_cc),
                        email_bcc=tools.email_split(mail.email_bcc),
                        reply_to=mail.reply_to,
                        attachments=attachments,
                        message_id=mail.message_id,
                        references=mail.references,
                        object_id=mail.res_id and ('%s-%s' % (mail.res_id, mail.model)),
                        subtype='html',
                        subtype_alternative='plain',
                        headers=headers)
                    processing_pid = email.pop("partner_id", None)

                    try:
                        res = IrMailServer.send_email(
                            msg, mail_server_id=mail.mail_server_id.id, smtp_session=smtp_session)
                        if processing_pid:
                            success_pids.append(processing_pid)
                        processing_pid = None
                    except AssertionError as error:
                        if str(error) == IrMailServer.NO_VALID_RECIPIENT:
                            failure_type = "RECIPIENT"
                            # No valid recipient found for this particular
                            # mail item -> ignore error to avoid blocking
                            # delivery to next recipients, if any. If this is
                            # the only recipient, the mail will show as failed.
                            _logger.info("Ignoring invalid recipients for mail.mail %s: %s",
                                         mail.message_id, email.get('email_to'))
                        else:
                            raise
                if res:  # mail has been sent at least once, no major exception occured
                    mail.write({'state': 'sent', 'message_id': res, 'failure_reason': False})
                    _logger.info('Mail with ID %r and Message-Id %r successfully sent', mail.id, mail.message_id)
                    # /!\ can't use mail.state here, as mail.refresh() will cause an error
                    # see revid:odo@openerp.com-20120622152536-42b2s28lvdv3odyr in 6.1
                mail._postprocess_sent_message(success_pids=success_pids, failure_type=failure_type)
            except MemoryError:
                # prevent catching transient MemoryErrors, bubble up to notify user or abort cron job
                # instead of marking the mail as failed
                _logger.exception(
                    'MemoryError while processing mail with ID %r and Msg-Id %r. Consider raising the --limit-memory-hard startup option',
                    mail.id, mail.message_id)
                # mail status will stay on ongoing since transaction will be rollback
                raise
            except (psycopg2.Error, smtplib.SMTPServerDisconnected):
                # If an error with the database or SMTP session occurs, chances are that the cursor
                # or SMTP session are unusable, causing further errors when trying to save the state.
                _logger.exception(
                    'Exception while processing mail with ID %r and Msg-Id %r.',
                    mail.id, mail.message_id)
                raise
            except Exception as e:
                failure_reason = tools.ustr(e)
                _logger.exception('failed sending mail (id: %s) due to %s', mail.id, failure_reason)
                mail.write({'state': 'exception', 'failure_reason': failure_reason})
                mail._postprocess_sent_message(success_pids=success_pids, failure_reason=failure_reason, failure_type='UNKNOWN')
                if raise_exception:
                    if isinstance(e, (AssertionError, UnicodeEncodeError)):
                        if isinstance(e, UnicodeEncodeError):
                            value = "Invalid text: %s" % e.object
                        else:
                            # get the args of the original error, wrap into a value and throw a MailDeliveryException
                            # that is an except_orm, with name and value as arguments
                            value = '. '.join(e.args)
                        raise MailDeliveryException(_("Mail Delivery Failed"), value)
                    raise

            if auto_commit is True:
                self._cr.commit()
        return True


class MailThread(models.AbstractModel):
    _inherit = 'mail.thread'
    email_bcc=fields.Char("email_bcc")



    @api.multi
    @api.returns('mail.message', lambda value: value.id)
    def message_post(self, **kwargs):
        kwargs.update({'email_cc_ids': [(6, 0, kwargs.get('email_cc_ids'))] if kwargs.get('email_cc_ids') else False,
                       'email_bcc_ids': [(6, 0, kwargs.get('email_bcc_ids'))] if kwargs.get('email_bcc_ids') else False,
                       'email_cc':kwargs['cc'] if kwargs.get('cc') else False,})
        return super(MailThread, self).message_post(**kwargs)


   













    

