To configure this module, you need to:

#. Go to *Settings > General Settings > Configure the incoming email gateway*.
#. Create or edit a record.
#. Configure properly.
#. Under *Default mail thread*, choose a model and record.

   Tip: if you do not know what to choose, we suggest you to use a mail
   channel.
