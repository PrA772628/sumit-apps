odoo.define('vpcs_survey_fields.survey_form', function(require) {
    'use strict';
    var publicWidget = require('web.public.widget');
    var SurveyFormWidget = require('survey.form');

    SurveyFormWidget.include({
        init: function(parent, options) {
            this._super.apply(this, arguments);
            this.handleFiles = this.handleFiles.bind(this);
            this.binary_question = {};
        },
        start: function() {
            var self = this;
            return this._super.apply(this, arguments).then(function() {
                self.$('.o_survey_question_binary').each(function() {
                    self._initBinary($(this));
                });

                self.$('.signature').each(function() {
                    self._initSignature($(this), $(this).parent().parent());
                });
            });
        },
        _initBinary: function($input) {
            var self = this;
            $input[0].addEventListener('change', this.handleFiles);
        },
        _initSignature: function($sign, $buttons) {
            var self = this;
            if (!$sign.length) {
                return;
            }

            $sign.jSignature();

            $buttons.find('.js_set_signature').click(function(event) {
                var $elem = $(event.currentTarget),
                    $parent = $elem.parents('.panel-signature'),
                    $input = $parent.find("input");
                var datapair = $parent.find('.signature').jSignature("getData", "image");
                if ($input && $input.length && datapair.length > 1) {
                    $input.attr('value', datapair[1]);
                }
            });

            $buttons.find('.js_reset_signature').click(function(event) {
                var $elem = $(event.currentTarget),
                    $parent = $elem.parents('.panel-signature'),
                    $input = $parent.find("input");
                $parent.find('.signature').jSignature("reset");
                $input.attr('value', '');
            });
        },
        get_file_load: function(file) {
            $.blockUI({
                message: "Loading..."
            });
            if (!file) {
                $.unblockUI();
                return Promise.reject();
            }
            return new Promise(function(resolve, reject) {
                var reader = new FileReader();
                reader.addEventListener('load', function() {
                    $.unblockUI();
                    resolve(reader.result);
                });
                reader.addEventListener('abort', function() {
                    $.unblockUI();
                    reject();
                });
                reader.addEventListener('error', function() {
                    $.unblockUI();
                    reject();
                });
                reader.readAsDataURL(file);
            });
        },
        handleFiles: async function(event) {
            var self = this;
            const file = event.target.files[0];
            const questionID = parseInt(event.target.name);
            const result = await this.get_file_load(file);
            const base64String = result;
            base64String.substr(base64String.indexOf(', ') + 1);
            self.binary_question[questionID] = {
                'filename': file.name,
                'datas': base64String,
                'size': file.size,
                'type': file.type
            }
        },
        _prepareSubmitValues: function(formData, params) {
            var self = this;
            this._super(formData, params);
            this.$('[data-question-type]').each(function() {
                switch ($(this).data('questionType')) {
                    case 'name':
                        params = self._prepareSubmitNames(params, $(this), this.value, $(this).attr('name'));
                        break;
                    case 'm2o':
                        params = self._prepareSubmitM2o(params, $(this), this.value, $(this).attr('name'));
                        break;
                    case 'address':
                        params = self._prepareSubmitAddress(params, $(this), this.value, $(this).attr('name'));
                        // console.log('___ params 4 : ', params);
                        break;
                    case 'binary':
                        params = self._prepareSubmitBinary(params, $(this), this.value, $(this).attr('name'));
                        // console.log('___ params 4 binary : ', params);
                        break;
                    case 'sign':
                        params = self._prepareSubmitSignature(params, $(this), this.value, $(this).attr('name'));
                        break;
                }
            });
        },
        _prepareSubmitSignature: function(params, $element, value, questionId) {
            params[questionId] = value;
            return params;
        },
        _prepareSubmitBinary: function(params, $element, value, questionId) {
            // console.log(params,"elemnts====\n", $element,"value========", value,"question id=======", questionId)
            // if (!_.has(this.binary_question, parseInt(questionId))) 
            // alert("in if")
            params[questionId] = value;
                // return params[parseInt(questionId)] = {};
            params[parseInt(questionId)] = this.binary_question[parseInt(questionId)];
            return params;
        },
        _prepareSubmitM2o: function(params, $element, value, questionId) {
            params[questionId] = value;
            return params;
        },
        _onNextScreenDone: function(result, options) {
            this._super(result, options);
            var self = this;
            if (result && !result.error) {
                this.$('.o_survey_question_binary').each(function() {
                    self._initBinary($(this));
                });
                this.$('.signature').each(function() {
                    self._initSignature($(this), $(this).parent().parent());
                });
                this.$('select.o_survey_question_value_m2o').each(function(index, $el) {
                    var value = $($el).attr('value');
                    var name = $($el).attr('name');
                    self.$(".form-control[name='" + name + "'], option[value='" + value + "']").attr('selected', 'selected');
                });

                this.$('select.o_survey_question_state_id').each(function(index, $el) {
                    var value = $($el).attr('value');
                    var name = $($el).attr('name');
                    self.$(".form-control[name='" + name + "'], option[value='" + value + "']").attr('selected', 'selected');
                });

                this.$('select.o_survey_question_country_id').each(function(index, $el) {
                    var value = $($el).attr('value');
                    var name = $($el).attr('name');
                    self.$(".form-control[name='" + name + "'], option[value='" + value + "']").attr('selected', 'selected');
                });

                this.$('input.o_survey_question_sign').each(function(index, $el) {
                    var value = $($el).val();
                    $($el).attr('src', "data:image/png;base64," + value);
                    $($el).parent().find('.signature').jSignature("setData", "data:image/png;base64," + value);
                });
            }
        },
        _prepareSubmitNames: function(params, $element, value, questionId) {
            var questionValue = questionId.split('__');
            if (questionValue[0] in params) {
                if (params[questionValue[0]].constructor === Object) {
                    params[questionValue[0]][questionValue[1]] = value;
                }
            } else {
                var final_value = {};
                final_value[questionId] = value;
                params[questionId] = final_value[questionId];
            }
            return params;
        },
        _prepareSubmitAddress: function(params, $element, value, questionId) {
            var questionValue = questionId.split('__');
            if (questionValue[0] in params) {
                if (params[questionValue[0]].constructor === Object) {
                    params[questionValue[0]][questionValue[1]] = value;
                }
            } else {
                var final_value = {};
                final_value[questionId] = value;
                params[questionId] = final_value[questionId];
            }
            return params;
        },
        _validateForm: function($form, formData) {
            var self = this;
            var errors = {};

            this._resetErrors();

            var data = {};
            formData.forEach(function(value, key) {
                data[key] = value;
            });

            var inactiveQuestionIds = this.options.sessionInProgress ? [] : this._getInactiveConditionalQuestionIds();
            $form.find('[data-question-type]').each(function() {
                var $input = $(this);
                var $questionWrapper = $input.closest(".js_question-wrapper");
                var questionId = $questionWrapper.attr('id');

                // If question is inactive, skip validation.
                if (inactiveQuestionIds.includes(parseInt(questionId))) {
                    return;
                }
                var questionRequired = $questionWrapper.data('required');
                switch ($input.data('questionType')) {
                    case 'char_box':
                        if (questionRequired && !$input.val()) {
                            // errors[questionId] = constrErrorMsg;
                        }
                }
            });
            if (_.keys(errors).length > 0) {
                this._showErrors(errors);
                return false;
            }
            return this._super($form, formData)
        },
    });

});