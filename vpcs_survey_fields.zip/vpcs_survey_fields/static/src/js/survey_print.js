odoo.define('vpcs_survey_fields.print', function(require) {
    'use strict';

    var SurveyPrintWidget = require('survey.print');

    SurveyPrintWidget.include({
        start: function() {
            var self = this;
            return this._super.apply(this, arguments).then(function() {
                
                self.$('select.o_survey_question_value_m2o').each(function(index, $el) {
                    var value = $($el).attr('value');
                    var name = $($el).attr('name');
                    $($el).find(".form-control[name='" + name + "'], option[value='" + value + "']").attr('selected', 'selected');
                });

                self.$('select.o_survey_question_state_id').each(function(index, $el) {
                    var value = $($el).attr('value');
                    var name = $($el).attr('name');
                    $($el).find(".form-control[name='" + name + "'], option[value='" + value + "']").attr('selected', 'selected');
                });

                self.$('select.o_survey_question_country_id').each(function(index, $el) {
                    var value = $($el).attr('value');
                    var name = $($el).attr('name');
                    $($el).find(".form-control[name='" + name + "'], option[value='" + value + "']").attr('selected', 'selected');
                });

                self.$('img.o_survey_question_sign').each(function(index, $el) {
                    var value = $($el).attr('src');
                    if(!value || value == undefined) {
                        $($el).parent().find('.signature').jSignature();
                        $($el).remove();
                    }else{
                        $($el).attr('src', "data:image/png;base64," + value);
                        $($el).parent().find('.signature').jSignature("setData", "data:image/png;base64," + value);
                    }
                });
            });
        },
    });
});