# -*- coding: utf-8 -*-
import base64
from odoo import api, fields, models, tools, SUPERUSER_ID, _
import re


ADDRESS_FIELDS = ['street', 'street2', 'city', 'zip', 'state_id', 'country_id']
NAME_FIELDS = ['first_name', 'middle_name', 'last_name']


class SurveyQuestion(models.Model):
    _inherit = 'survey.question'

    question_type = fields.Selection(selection_add=[
        ('name', 'First Name - Middle Name - Last Name'),
        ('m2o', 'Relational Field'),
        ('binary', 'Upload File'),
        ('address', 'Address'),
        ('sign', 'Digital Signature')
        ])
    model_id = fields.Many2one("ir.model", string="Model", domain="[('transient','=',False)]")
    validation_type = fields.Selection(selection=[
        ('url', 'Validation URL'),
        ('phone', 'Validation Phone'),
        ('email', 'Validation E-Mail')],
        string="Validations")


    show_sign = fields.Boolean(string='Show in Result ?')


    def _get_stats_data(self, user_input_lines):
        if self.question_type == 'address':
            return self._get_stats_graph_data_address(user_input_lines)
        elif self.question_type == 'm2o':
            return self._get_stats_graph_data_m2o(user_input_lines)
        elif self.question_type == 'sign':
            return self._get_stats_graph_data_sign(user_input_lines)
        return super(SurveyQuestion, self)._get_stats_data(user_input_lines)

    def _get_stats_graph_data_sign(self, user_input_lines):
        graph_data = []
        table_data = []
        answers = {}
        for input_line in user_input_lines:
            table_data.append(input_line)
        return table_data, graph_data

    def _get_stats_graph_data_address(self, user_input_lines):
        graph_data = []
        table_data = []
        answers = {}
        for input_line in user_input_lines:
            _country_id = int(input_line.country_id.id or 0)
            answers.setdefault(_country_id, {
                'text': input_line.country_id.name or _('Undefined'),
                'count': 0,
                'id': _country_id
            })
            answers[_country_id]['count'] += 1
            table_data.append(input_line)
        for key in answers:
            graph_data.append(answers[key])
        return table_data, graph_data

    def _get_stats_graph_data_m2o(self, user_input_lines):
        graph_data = []
        table_data = []
        answers = {}
        for input_line in user_input_lines:
            _m2o_id = int(input_line.value_m2o or 0)
            answers.setdefault(_m2o_id, {
                'text': input_line.value_text or _('Undefined'),
                'count': 0,
                'id': _m2o_id
            })
            answers[_m2o_id]['count'] += 1
        for key in answers:
            graph_data.append(answers[key])
            table_data.append({'text': answers[key]['text'], 'count': answers[key]['count']})
        return table_data, graph_data

    def _validate_char_box(self, answer):
        errors = {}
        if self.validation_type == 'email' or self.validation_email:
            if not tools.email_normalize(answer):
                errors.update({self.id: _('This answer must be an email address')})

        if answer and self.validation_type == 'url':
            regex = re.compile(
                r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'
                r'localhost|'
                r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
                r'(?::\d+)?'
                r'(?:/?|[/?]\S+)$', re.IGNORECASE)
            if re.match(regex, answer) is None:
                errors.update({self.id: _("Invalid URL format. (eg. www.example.com)")})
            count = 0
            website_name_index=0
            corporation_index=0
  
            for i in answer:
                if count==1:
                    website_name_index=website_name_index+1
                    
                if count==2:
                    corporation_index=corporation_index+1
                    
                if i == '.':
                    count = count + 1
            if website_name_index-1==0 or corporation_index==0:
                errors.update({self.id: _("Invalid URL format. (eg. www.example.com)")})

            if count<2 or count>2:
                errors.update({self.id: _("Invalid URL format. (eg. www.example.com)")})

            elif not answer.startswith("www"):
                errors.update({self.id: _("Invalid URL format. (eg. www.example.com)")})
                



        if answer and self.validation_type == 'phone' and not self.validation_required:
            ALLOWED_PHONE_CHAR = list(map(str, range(0, 10))) + [' ', '+']
            for a in answer:
                if a not in ALLOWED_PHONE_CHAR:
                    errors.update({self.id: _("Invalid Phone Format. (eg. 9876543210)")})
                    break

        # Answer validation (if properly defined)
        # Length of the answer must be in a range
        if self.validation_required:
            if not (self.validation_length_min <= len(answer) <= self.validation_length_max):
                errors.update({self.id: self.validation_error_msg})
        return errors

    def validate_question(self, answer, comment=None):
        res = super(SurveyQuestion, self).validate_question(answer, comment)
        if isinstance(answer, str):
            answer = answer.strip()
        if self.question_type == 'name':
            return self._validate_name(answer)
        if self.question_type == 'm2o':
            return self.validate_m2o(answer)
        if self.question_type == 'address':
            # print ('___ self.question_type : ', self.question_type,self.id);
            return self.validate_address(answer)
        if self.question_type == 'sign':
            return self.validate_sign(answer)
        if self.question_type == 'binary':
            # print ('___ self.question_type : ', self.question_type,self.id);
            return self.validate_binary(answer)
        return res

    def validate_m2o(self, answer):
        if self.constr_mandatory and (answer=='false' or answer==[]):
            return {self.id: self.constr_error_msg}
        return {}

    def validate_sign(self, answer):

        if self.constr_mandatory and not answer:
            return {self.id: self.constr_error_msg}
        return {}

    def _validate_name(self, answer):
        if self.constr_mandatory:
            if not answer.get('first_name') or not answer.get('last_name'):
                return {self.id: self.constr_error_msg}
        return {}

    def validate_binary(self, answer):
        if self.constr_mandatory and (answer==[] or answer==''):
            return {self.id: self.constr_error_msg}
        return {}

        

    def validate_address(self, answer):
        address = []
        from pprint import pprint
        if answer.get('country_id')=='':
            answer.update({
                'country_id':None
                }) 
        if answer.get('state_id')=='':
            answer.update({
                'state_id':None
                })

        for f_name in ADDRESS_FIELDS:
            if answer.get(f_name):
                address.append(answer.get(f_name, '').strip())

        if self.constr_mandatory and not address:
            return {self.id: self.constr_error_msg}
        return {}

class SurveyUserInputLine(models.Model):
    _inherit = 'survey.user_input.line'

    answer_type = fields.Selection(selection_add=[
        ('name', 'First Name - Middle Name - Last Name'),
        ('m2o', 'Relational Field'),
        ('binary', 'Upload File'),
        ('address', 'Address'),
        ('sign', 'Digital Signature')
        ])

    first_name = fields.Char("First Name")
    middle_name = fields.Char("Middle Name")
    last_name = fields.Char("Last Name")

    value_m2o = fields.Integer('ID Selected in Relational Field')
    value_text = fields.Char("Text answer")
    attachment_id = fields.Many2one('ir.attachment', string='Attachment')

    img_sign = fields.Binary("Digital Signature")

    street = fields.Char()
    street2 = fields.Char()
    zip = fields.Char(change_default=True)
    city = fields.Char()
    state_id = fields.Many2one("res.country.state", string='State', ondelete='restrict')
    country_id = fields.Many2one('res.country', string='Country', ondelete='restrict')


    @api.constrains('skipped', 'answer_type')
    def _check_answer_type_skipped(self):
        for line in self:
            # allow 0 for numerical box
            if line.answer_type == 'name':
                continue
            elif line.answer_type == 'binary':
                continue
            elif line.answer_type == 'address':
                continue
            elif line.answer_type == 'sign':
                continue
            else:
                return super(SurveyUserInputLine, self)._check_answer_type_skipped()

            if field_name and not line[field_name]:
                raise ValidationError(_('The answer must be in the right type'))


class SurveyUserInput(models.Model):
    """ Metadata for a set of one user's answers to a particular survey """
    _inherit = "survey.user_input"

    attachment_ids = fields.Many2many('ir.attachment', string="Attachments")
    attachment_count = fields.Integer("Attachment Count", compute="_compute_attachment_count")

    def _compute_attachment_count(self):
        for rec in self:
            rec.attachment_count = len(rec.attachment_ids.ids)

    def save_lines(self, question, answer, comment=None):
        
        old_answers = self.env['survey.user_input.line'].search([
            ('user_input_id', '=', self.id),
            ('question_id', '=', question.id)
        ])
        if question.question_type == 'name':
            self.save_line_name(question, old_answers, answer, comment)
        elif question.question_type == 'm2o':
            self.save_line_m2o(question, old_answers, answer, comment)
        elif question.question_type == 'binary':
            self.save_line_binary(question, old_answers, answer, comment)
        elif question.question_type == 'address':
            self.save_line_address(question, old_answers, answer, comment)
        elif question.question_type == 'sign':
            self.save_line_sign(question, old_answers, answer, comment)
        else:
            return super(SurveyUserInput, self).save_lines(question, answer, comment)

    def save_line_binary(self, question, old_answers, answer, comment):
        vals = self._get_line_answer_values(question, answer, question.question_type)

        attachment = self.env['ir.attachment'].with_user(self.env['res.users'].browse(SUPERUSER_ID))
        attachment_value = vals.get('attachment', {})
        record = self.env['survey.user_input.line'].search([
            ('user_input_id', '=', vals.get('user_input_id')),
            ('survey_id', '=', question.survey_id.id),
            ('question_id', '=', question.id)], limit=1)
        if attachment_value and not record.attachment_id:
            # Create New Attachment if not Found
            attachment_value.update({'res_id': record.id, 'description': question.description})
            attachment = attachment.create(attachment_value)
            vals.update({'attachment_id': attachment.id})
        else:
            vals.update({'answer_type': None, 'skipped': True})
        if 'attachment' in vals:
            vals.pop('attachment')
        if old_answers:
            old_answers.write(vals)
            return old_answers
        else:
            record = self.env['survey.user_input.line'].create(vals)
            if attachment:
                attachment.write({'res_id': record.id})
                main_answer = self.env['survey.user_input'].with_user(self.env['res.users'].browse(SUPERUSER_ID)).browse(vals.get('user_input_id'))
                main_answer.attachment_ids = [(4, attachment.id)]
            return record

    def save_line_address(self, question, old_answers, answer, comment):
        vals = self._get_line_answer_values(question, answer, question.question_type)
        if old_answers:
            old_answers.write(vals)
            return old_answers
        else:
            return self.env['survey.user_input.line'].create(vals)


    def save_line_name(self, question, old_answers, answer, comment):
        vals = self._get_line_answer_values(question, answer, question.question_type)
        if old_answers:
            old_answers.write(vals)
            return old_answers
        else:
            return self.env['survey.user_input.line'].create(vals)

    def save_line_m2o(self, question, old_answers, answer, comment):
        vals = self._get_line_answer_values(question, answer, question.question_type)
        if old_answers:
            old_answers.write(vals)
            return old_answers
        else:
            return self.env['survey.user_input.line'].create(vals)
        return True

    def save_line_sign(self, question, old_answers, answer, comment):
        vals = self._get_line_answer_values(question, answer, question.question_type)
        if old_answers:
            old_answers.write(vals)
            return old_answers
        else:
            return self.env['survey.user_input.line'].create(vals)
        return True

    def _get_line_answer_values(self, question, answer, answer_type):
        vals = {
            'user_input_id': self.id,
            'question_id': question.id,
            'skipped': False,
            'answer_type': answer_type,
        }
        if not answer or (isinstance(answer, str) and not answer.strip()):
            vals.update(answer_type=None, skipped=True)
            return vals

        if answer_type == 'name':
            vals['first_name'] = answer.get('first_name', '')
            vals['middle_name'] = answer.get('middle_name', )
            vals['last_name'] = answer.get('last_name', )
        elif answer_type == 'm2o':
            if answer and answer != 'false':
                record_id = int(answer)
                record = self.env[question.model_id.model].with_user(self.env['res.users'].browse(SUPERUSER_ID)).browse(record_id)
                vals.update({
                    'value_m2o': record_id,
                    'value_text': record.display_name,
                })
            else:
                vals.update({'answer_type': None, 'skipped': True})
        elif answer_type == 'binary':
            attachment_value = {}
            if answer and 'datas' in answer:
                datas = answer.get('datas', '')
                split_datas = datas.split('base64,')[1]
                decode = base64.b64decode(split_datas)
                encoded = base64.encodestring(decode)

                attachment_value = {
                    'name': answer.get('filename'),
                    'datas': encoded,
                    'store_fname': answer.get('filename'),
                    'res_model': 'survey.user_input.line',
                    'file_size': answer.get('size'),
                }
            vals.update({'attachment': attachment_value})
        elif answer_type == 'address':
            address = {}
            vals['street'] = answer.get('street', '')
            vals['street2'] = answer.get('street2', '')
            vals['city'] = answer.get('city', '')
            vals['zip'] = answer.get('zip', '')
            vals['state_id'] = answer.get('state_id', False)
            vals['country_id'] = answer.get('country_id', False)
            for fname  in ADDRESS_FIELDS:
                address.update({fname: answer.get(fname)})
                if(fname == 'state_id' and answer.get(fname) == 'false'):
                    address.update({fname: False})
                if(fname == 'country_id' and answer.get(fname) == 'false'):
                    address.update({fname: False})
            if address:
                vals.update(address)
            else:
                vals.update({'answer_type': None, 'skipped': True})
        elif answer_type == 'sign':
            if answer:
                vals.update({'img_sign': answer})
            else:
                vals.update({'answer_type': None, 'skipped': True})
        else:
            return  super(SurveyUserInput, self)._get_line_answer_values(question, answer, answer_type)
        return vals